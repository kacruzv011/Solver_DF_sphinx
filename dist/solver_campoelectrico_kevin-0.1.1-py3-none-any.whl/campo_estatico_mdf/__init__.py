# Este archivo hace que el directorio 'campo_estatico_mdf' sea un paquete de Python.
from .solver import LaplaceSolver2D
